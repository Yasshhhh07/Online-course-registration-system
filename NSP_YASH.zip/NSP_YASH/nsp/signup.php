<?php
// Connect to the MySQL database
$conn = new mysqli("localhost", "root", "", "course");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $first_name = trim($_POST["first_name"]);
    $last_name = trim($_POST["last_name"]);
    $email = trim($_POST["email"]);
    $course_spec = trim($_POST["course_spec"]);

    // Prepare SQL query to insert data securely
    $stmt = $conn->prepare("INSERT INTO registration (first_name, last_name, email, course_spec) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $first_name, $last_name, $email, $course_spec);

    // Execute and check result
    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!'); window.location.href='sample4.html';</script>";
    } else {
        echo "<script>alert('Error while registering. Please try again.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>